#!/usr/bin/env bash
# Local build (needs Flutter + Android SDK installed): ./build_apk.sh
# Optional Firebase values (otherwise the app runs in demo mode):
#   FB_API_KEY=... FB_APP_ID=... FB_PROJECT_ID=... FB_SENDER_ID=... ./build_apk.sh
set -euo pipefail
cd "$(dirname "$0")"

bash tool/prepare_android.sh
flutter pub get
flutter build apk --release \
  --dart-define=FB_API_KEY="${FB_API_KEY:-}" \
  --dart-define=FB_APP_ID="${FB_APP_ID:-}" \
  --dart-define=FB_PROJECT_ID="${FB_PROJECT_ID:-}" \
  --dart-define=FB_SENDER_ID="${FB_SENDER_ID:-}" \
  --dart-define=FB_STORAGE_BUCKET="${FB_STORAGE_BUCKET:-}"

echo
echo "APK: build/app/outputs/flutter-apk/app-release.apk"
