#!/usr/bin/env bash
# Generates the Android platform project around the WorkPulse sources and
# applies the settings the app needs. Safe to run repeatedly.
set -euo pipefail
cd "$(dirname "$0")/.."

BACKUP="$(mktemp -d)"
cp -r lib "$BACKUP/lib"
cp pubspec.yaml "$BACKUP/pubspec.yaml"

# Creates android/ (and a template lib/, pubspec, test/ that we then restore).
flutter create --platforms=android --org com.workpulse --project-name workpulse .

rm -rf lib
cp -r "$BACKUP/lib" lib
cp "$BACKUP/pubspec.yaml" pubspec.yaml
rm -rf test

# Firebase needs minSdk 23.
for f in android/app/build.gradle.kts android/app/build.gradle; do
  if [ -f "$f" ]; then
    sed -i 's/flutter\.minSdkVersion/23/; s/minSdk = [0-9][0-9]*/minSdk = 23/; s/minSdkVersion [0-9][0-9]*/minSdkVersion 23/' "$f"
  fi
done

# Release builds need the INTERNET permission (Firebase).
MANIFEST=android/app/src/main/AndroidManifest.xml
if ! grep -q 'android.permission.INTERNET' "$MANIFEST"; then
  sed -i 's#\(<manifest[^>]*>\)#\1\n    <uses-permission android:name="android.permission.INTERNET"/>#' "$MANIFEST"
fi

# App name on the launcher.
sed -i 's/android:label="[^"]*"/android:label="WorkPulse"/' "$MANIFEST"

echo "Android project ready."
