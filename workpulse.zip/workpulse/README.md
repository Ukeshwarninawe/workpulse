# WorkPulse — Employee Workload & Resource Allocation Platform

Flutter + Firebase app built from the WorkPulse presentation
(*"Right Work. Right People. Right Time."*).

## What's in the app

| Deck slide | Feature in the app |
|---|---|
| Employee Module | Home (workload %, due soon, completed, in-progress tasks), Tasks (active/completed, tap to update progress), Team, Profile |
| Manager Module | Dashboard (Capacity / At Risk / Overload / Available), live team workload bars with HIGH / MID / LOW pills, **Manager Action** suggestion with Review → Reallocate |
| Workload Intelligence | 92% overloaded · 76% watch · 42% available thresholds (≥85 high, 60–84 mid, <60 low) |
| Project Health & Smart Alerts | ON TRACK / AT RISK / DELAYED per project; alerts such as "Rahul has 3 tasks approaching deadline", "Project B has multiple overdue tasks", "Priya has available capacity" |
| Workflow | Login → role (Employee / Manager) → tasks & projects → Firebase store & sync → analysis → alert / reallocate |
| Tech stack | Flutter (Dart, widgets) + Firebase Auth + Cloud Firestore (real-time sync) |

**How the numbers are computed** (`lib/analytics.dart`)
- Workload % = open task hours ÷ weekly capacity (40 h).
- Project progress = effort-weighted average of task progress. Status compares it with how far the calendar says the project should be (gap > 30 pts → Delayed, > 10 pts or 2+ overdue tasks → At Risk).

## Run without any setup: Demo mode

If no Firebase values are supplied, the app runs on built-in sample data
(Rahul 92 %, Aman 76 %, Priya 42 %, Neha 35 %, Projects A/B/C…). Use the
**Manager** / **Employee** buttons on the login screen. Changes are kept in memory only.

## Get the APK (no installs on your PC)

1. Create a new GitHub repository and upload this folder's contents (or `git push` them).
2. Open the **Actions** tab → **Build WorkPulse APK** → *Run workflow* (it also runs on every push).
3. When it finishes (~5–8 min), download **WorkPulse-APK** from the run page, unzip, and install
   `app-release.apk` on your phone (allow "install unknown apps").

## Build locally instead

Needs Flutter (stable) and the Android SDK: `./build_apk.sh`
→ `build/app/outputs/flutter-apk/app-release.apk`

## Turn on Firebase (real accounts + live sync)

1. Firebase console → create a project → add an **Android app** (package `com.workpulse.workpulse`).
2. Build → **Authentication** → enable **Email/Password**.
3. Build → **Firestore Database** → create database, then paste `firestore.rules` into the Rules tab.
4. From Project settings → your Android app, copy: API key, App ID, Project ID, Sender ID.
5. Provide them either way:
   - GitHub: repo Settings → Secrets and variables → Actions → add `FB_API_KEY`, `FB_APP_ID`, `FB_PROJECT_ID`, `FB_SENDER_ID` (optional `FB_STORAGE_BUCKET`), then re-run the workflow; or
   - Local: `FB_API_KEY=… FB_APP_ID=… FB_PROJECT_ID=… FB_SENDER_ID=… ./build_apk.sh`.
6. Open the app, **Create account** as a Manager, then have employees register.
   Add projects and assign tasks from the manager account.

Firestore collections: `users`, `projects`, `tasks` (fields in `lib/data/firebase_backend.dart`).

## Notes / limits

- Registration lets a user pick their own role (fine for a college project). For production,
  assign roles from an admin tool or Cloud Function instead.
- Cloud Messaging (push notifications) from the deck's stack slide is not wired up; alerts
  are computed live inside the app. Adding FCM needs a `google-services.json` and a Cloud Function trigger.
- The APK is signed with the debug key, which is fine for installing and demoing, not for the Play Store.
