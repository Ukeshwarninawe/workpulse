import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';

import 'app_state.dart';
import 'data/backend.dart';
import 'data/demo_backend.dart';
import 'data/firebase_backend.dart';
import 'firebase_config.dart';
import 'models.dart';
import 'screens/employee_shell.dart';
import 'screens/login_screen.dart';
import 'screens/manager_shell.dart';
import 'theme.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  Backend backend = DemoBackend();
  if (FirebaseConfig.isConfigured) {
    try {
      await Firebase.initializeApp(options: FirebaseConfig.options);
      backend = FirebaseBackend();
    } catch (_) {
      // Fall back to demo mode so the app always starts.
      backend = DemoBackend();
    }
  }

  final state = AppState(backend);
  try {
    await state.init();
  } catch (_) {
    // Start at the login screen if restoring the session fails.
  }
  runApp(WorkPulseApp(state: state));
}

class WorkPulseApp extends StatelessWidget {
  const WorkPulseApp({super.key, required this.state});
  final AppState state;

  @override
  Widget build(BuildContext context) {
    return AppScope(
      state: state,
      child: MaterialApp(
        title: 'WorkPulse',
        debugShowCheckedModeBanner: false,
        theme: buildTheme(),
        home: const _Root(),
      ),
    );
  }
}

class _Root extends StatelessWidget {
  const _Root();

  @override
  Widget build(BuildContext context) {
    final me = AppScope.of(context).me;
    if (me == null) return const LoginScreen();
    return me.role == Role.manager ? const ManagerShell() : const EmployeeShell();
  }
}
