enum Role { employee, manager }

class AppUser {
  const AppUser({
    required this.id,
    required this.name,
    required this.email,
    required this.role,
    this.weeklyHours = 40,
  });

  final String id;
  final String name;
  final String email;
  final Role role;

  /// Weekly capacity in hours. Workload % = open task hours / weeklyHours.
  final int weeklyHours;

  String get firstName {
    final parts = name.trim().split(' ');
    return parts.isEmpty || parts.first.isEmpty ? name : parts.first;
  }
}

class Project {
  const Project({
    required this.id,
    required this.name,
    required this.start,
    required this.deadline,
    this.description = '',
  });

  final String id;
  final String name;
  final String description;
  final DateTime start;
  final DateTime deadline;
}

class TaskItem {
  const TaskItem({
    required this.id,
    required this.title,
    required this.projectId,
    required this.assigneeId,
    required this.progress,
    required this.due,
    required this.hours,
  });

  /// Empty id means "not saved yet"; the backend assigns one.
  final String id;
  final String title;
  final String projectId;
  final String assigneeId;

  /// 0..100
  final int progress;
  final DateTime due;

  /// Estimated effort in hours.
  final double hours;

  bool get done => progress >= 100;

  TaskItem copyWith({
    String? title,
    String? projectId,
    String? assigneeId,
    int? progress,
    DateTime? due,
    double? hours,
  }) {
    return TaskItem(
      id: id,
      title: title ?? this.title,
      projectId: projectId ?? this.projectId,
      assigneeId: assigneeId ?? this.assigneeId,
      progress: progress ?? this.progress,
      due: due ?? this.due,
      hours: hours ?? this.hours,
    );
  }
}

/// Everything the UI needs, delivered together by a backend.
class Snapshot {
  const Snapshot(this.users, this.projects, this.tasks);
  const Snapshot.empty()
      : users = const [],
        projects = const [],
        tasks = const [];

  final List<AppUser> users;
  final List<Project> projects;
  final List<TaskItem> tasks;
}

class AuthFailure implements Exception {
  AuthFailure(this.message);
  final String message;
  @override
  String toString() => message;
}
