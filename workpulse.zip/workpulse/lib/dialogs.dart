import 'package:flutter/material.dart';

import 'analytics.dart';
import 'app_state.dart';
import 'models.dart';
import 'theme.dart';
import 'widgets.dart';

Widget _sheetFrame(BuildContext ctx, List<Widget> children) {
  return SafeArea(
    child: SingleChildScrollView(
      padding: EdgeInsets.fromLTRB(
          20, 20, 20, 20 + MediaQuery.of(ctx).viewInsets.bottom),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: children,
      ),
    ),
  );
}

/// Employee: update progress on a task.
Future<void> showProgressSheet(BuildContext context, TaskItem task) {
  final state = AppScope.read(context);
  return showModalBottomSheet<void>(
    context: context,
    backgroundColor: C.panel,
    isScrollControlled: true,
    builder: (ctx) {
      double value = task.progress.toDouble();
      return StatefulBuilder(
        builder: (ctx, setSheet) => _sheetFrame(ctx, [
          Text(task.title,
              style: const TextStyle(
                  color: C.text, fontSize: 18, fontWeight: FontWeight.w800)),
          const SizedBox(height: 4),
          Text(
              '${state.projectById(task.projectId)?.name ?? 'No project'} • ${dueText(task.due, done: task.done)}',
              style: const TextStyle(color: C.muted)),
          const SizedBox(height: 18),
          Row(
            children: [
              const Text('Progress', style: TextStyle(color: C.muted)),
              const Spacer(),
              Text('${value.round()}%',
                  style: TextStyle(
                      color: progressColor(value.round()),
                      fontSize: 22,
                      fontWeight: FontWeight.w800)),
            ],
          ),
          Slider(
            value: value,
            min: 0,
            max: 100,
            divisions: 20,
            label: '${value.round()}%',
            onChanged: (v) => setSheet(() => value = v),
          ),
          const SizedBox(height: 8),
          Row(
            children: [
              Expanded(
                child: OutlinedButton(
                  onPressed: () => setSheet(() => value = 100),
                  child: const Text('Mark complete'),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: FilledButton(
                  onPressed: () {
                    Navigator.pop(ctx);
                    guard(context,
                        () => state.updateProgress(task, value.round()));
                  },
                  child: const Text('Save'),
                ),
              ),
            ],
          ),
        ]),
      );
    },
  );
}

/// Manager: move a task to another employee.
Future<void> showReassignSheet(BuildContext context, TaskItem task) {
  final state = AppScope.read(context);
  final analytics = state.analytics;
  return showModalBottomSheet<void>(
    context: context,
    backgroundColor: C.panel,
    isScrollControlled: true,
    builder: (ctx) {
      final options = analytics.loads.reversed.toList(); // least loaded first
      return _sheetFrame(ctx, [
        Text('Reassign "${task.title}"',
            style: const TextStyle(
                color: C.text, fontSize: 18, fontWeight: FontWeight.w800)),
        const SizedBox(height: 4),
        const Text('Least loaded people are listed first.',
            style: TextStyle(color: C.muted)),
        const SizedBox(height: 14),
        if (options.isEmpty) const EmptyNote('No employees yet.'),
        for (final l in options)
          ListTile(
            contentPadding: EdgeInsets.zero,
            enabled: l.user.id != task.assigneeId,
            title: Text(l.user.name,
                style: const TextStyle(
                    color: C.text, fontWeight: FontWeight.w700)),
            subtitle: Text(
                l.user.id == task.assigneeId
                    ? 'Current assignee'
                    : '${l.percent.round()}% workload • ${l.active} open tasks',
                style: const TextStyle(color: C.muted)),
            trailing: Pill(levelLabel(l.level), levelColor(l.level)),
            onTap: l.user.id == task.assigneeId
                ? null
                : () {
                    Navigator.pop(ctx);
                    guard(context, () => state.reassign(task, l.user.id));
                  },
          ),
      ]);
    },
  );
}

/// Manager: create or edit a task.
Future<void> showTaskEditor(BuildContext context, {TaskItem? existing}) {
  final state = AppScope.read(context);
  final employees = state.employees;
  final projects = state.data.projects;

  return showModalBottomSheet<void>(
    context: context,
    backgroundColor: C.panel,
    isScrollControlled: true,
    builder: (ctx) {
      final title = TextEditingController(text: existing?.title ?? '');
      final hours = TextEditingController(
          text: existing == null ? '8' : existing.hours.toString());
      String? projectId = existing?.projectId ??
          (projects.isNotEmpty ? projects.first.id : null);
      String? assigneeId = existing?.assigneeId ??
          (employees.isNotEmpty ? employees.first.id : null);
      DateTime due = existing?.due ?? DateTime.now().add(const Duration(days: 7));
      String? error;

      return StatefulBuilder(
        builder: (ctx, setSheet) => _sheetFrame(ctx, [
          Text(existing == null ? 'Assign new task' : 'Edit task',
              style: const TextStyle(
                  color: C.text, fontSize: 20, fontWeight: FontWeight.w800)),
          const SizedBox(height: 16),
          TextField(
            controller: title,
            textCapitalization: TextCapitalization.sentences,
            decoration: const InputDecoration(labelText: 'Task title'),
          ),
          const SizedBox(height: 12),
          DropdownButtonFormField<String>(
            initialValue: projectId,
            dropdownColor: C.card,
            decoration: const InputDecoration(labelText: 'Project'),
            items: [
              for (final p in projects)
                DropdownMenuItem(value: p.id, child: Text(p.name)),
            ],
            onChanged: (v) => setSheet(() => projectId = v),
          ),
          const SizedBox(height: 12),
          DropdownButtonFormField<String>(
            initialValue: assigneeId,
            dropdownColor: C.card,
            decoration: const InputDecoration(labelText: 'Assign to'),
            items: [
              for (final u in employees)
                DropdownMenuItem(
                  value: u.id,
                  child: Text(
                      '${u.name}  (${(state.analytics.loadOf(u.id)?.percent ?? 0).round()}%)'),
                ),
            ],
            onChanged: (v) => setSheet(() => assigneeId = v),
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(
                child: TextField(
                  controller: hours,
                  keyboardType:
                      const TextInputType.numberWithOptions(decimal: true),
                  decoration:
                      const InputDecoration(labelText: 'Estimated hours'),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: OutlinedButton.icon(
                  style: OutlinedButton.styleFrom(
                      minimumSize: const Size.fromHeight(56)),
                  icon: const Icon(Icons.event, size: 18),
                  label: Text(fmtDate(due)),
                  onPressed: () async {
                    final picked = await showDatePicker(
                      context: ctx,
                      initialDate: due,
                      firstDate: DateTime.now().subtract(const Duration(days: 365)),
                      lastDate: DateTime.now().add(const Duration(days: 365 * 3)),
                    );
                    if (picked != null) {
                      setSheet(() => due =
                          DateTime(picked.year, picked.month, picked.day, 23, 59));
                    }
                  },
                ),
              ),
            ],
          ),
          if (error != null) ...[
            const SizedBox(height: 10),
            Text(error!, style: const TextStyle(color: C.red)),
          ],
          const SizedBox(height: 18),
          FilledButton(
            style: FilledButton.styleFrom(
                minimumSize: const Size.fromHeight(52)),
            onPressed: () {
              final h = double.tryParse(hours.text.trim());
              if (title.text.trim().isEmpty) {
                setSheet(() => error = 'Please enter a task title.');
                return;
              }
              if (projectId == null || assigneeId == null) {
                setSheet(() => error = 'Create a project and add an employee first.');
                return;
              }
              if (h == null || h <= 0) {
                setSheet(() => error = 'Enter estimated hours greater than 0.');
                return;
              }
              final task = TaskItem(
                id: existing?.id ?? '',
                title: title.text.trim(),
                projectId: projectId!,
                assigneeId: assigneeId!,
                progress: existing?.progress ?? 0,
                due: due,
                hours: h,
              );
              Navigator.pop(ctx);
              guard(context, () => state.saveTask(task));
            },
            child: Text(existing == null ? 'Assign task' : 'Save changes'),
          ),
        ]),
      );
    },
  );
}

/// Manager: create a project.
Future<void> showProjectEditor(BuildContext context) {
  final state = AppScope.read(context);
  return showModalBottomSheet<void>(
    context: context,
    backgroundColor: C.panel,
    isScrollControlled: true,
    builder: (ctx) {
      final name = TextEditingController();
      final desc = TextEditingController();
      DateTime deadline = DateTime.now().add(const Duration(days: 30));
      String? error;
      return StatefulBuilder(
        builder: (ctx, setSheet) => _sheetFrame(ctx, [
          const Text('New project',
              style: TextStyle(
                  color: C.text, fontSize: 20, fontWeight: FontWeight.w800)),
          const SizedBox(height: 16),
          TextField(
            controller: name,
            textCapitalization: TextCapitalization.words,
            decoration: const InputDecoration(labelText: 'Project name'),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: desc,
            decoration:
                const InputDecoration(labelText: 'Description (optional)'),
          ),
          const SizedBox(height: 12),
          OutlinedButton.icon(
            style: OutlinedButton.styleFrom(
                minimumSize: const Size.fromHeight(52)),
            icon: const Icon(Icons.event, size: 18),
            label: Text('Deadline: ${fmtDate(deadline)}'),
            onPressed: () async {
              final picked = await showDatePicker(
                context: ctx,
                initialDate: deadline,
                firstDate: DateTime.now(),
                lastDate: DateTime.now().add(const Duration(days: 365 * 3)),
              );
              if (picked != null) {
                setSheet(() => deadline =
                    DateTime(picked.year, picked.month, picked.day, 23, 59));
              }
            },
          ),
          if (error != null) ...[
            const SizedBox(height: 10),
            Text(error!, style: const TextStyle(color: C.red)),
          ],
          const SizedBox(height: 18),
          FilledButton(
            style: FilledButton.styleFrom(
                minimumSize: const Size.fromHeight(52)),
            onPressed: () {
              if (name.text.trim().isEmpty) {
                setSheet(() => error = 'Please enter a project name.');
                return;
              }
              final project = Project(
                id: '',
                name: name.text.trim(),
                description: desc.text.trim(),
                start: DateTime.now(),
                deadline: deadline,
              );
              Navigator.pop(ctx);
              guard(context, () => state.saveProject(project));
            },
            child: const Text('Create project'),
          ),
        ]),
      );
    },
  );
}

/// Manager: confirm the suggested reallocation.
Future<void> showReallocationDialog(BuildContext context, Reallocation r) {
  final state = AppScope.read(context);
  return showDialog<void>(
    context: context,
    builder: (ctx) => AlertDialog(
      backgroundColor: C.panel,
      title: Text('Reallocate ${r.tasks.length} task${r.tasks.length == 1 ? '' : 's'}'),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
              '${r.from.user.firstName} (${r.from.percent.round()}%)  →  ${r.to.user.firstName} (${r.to.percent.round()}%)',
              style: const TextStyle(
                  color: C.cyan, fontWeight: FontWeight.w800)),
          const SizedBox(height: 12),
          for (final t in r.tasks)
            Padding(
              padding: const EdgeInsets.only(bottom: 6),
              child: Text('• ${t.title} (${t.hours.toStringAsFixed(t.hours % 1 == 0 ? 0 : 1)}h)',
                  style: const TextStyle(color: C.text)),
            ),
        ],
      ),
      actions: [
        TextButton(
            onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
        FilledButton(
          onPressed: () {
            Navigator.pop(ctx);
            guard(context, () => state.applyReallocation(r));
          },
          child: const Text('Reallocate'),
        ),
      ],
    ),
  );
}
