import 'package:firebase_core/firebase_core.dart';

/// Paste your Firebase project values here (Firebase console ->
/// Project settings -> Your apps -> Android app), or pass them at build time:
///
///   flutter build apk --dart-define=FB_API_KEY=... --dart-define=FB_APP_ID=...
///     --dart-define=FB_PROJECT_ID=... --dart-define=FB_SENDER_ID=...
///
/// While these are empty the app runs in DEMO MODE with local sample data,
/// so the APK always starts and is fully usable.
class FirebaseConfig {
  static const apiKey = String.fromEnvironment('FB_API_KEY', defaultValue: '');
  static const appId = String.fromEnvironment('FB_APP_ID', defaultValue: '');
  static const projectId =
      String.fromEnvironment('FB_PROJECT_ID', defaultValue: '');
  static const senderId =
      String.fromEnvironment('FB_SENDER_ID', defaultValue: '');
  static const storageBucket =
      String.fromEnvironment('FB_STORAGE_BUCKET', defaultValue: '');

  static bool get isConfigured =>
      apiKey.isNotEmpty &&
      appId.isNotEmpty &&
      projectId.isNotEmpty &&
      senderId.isNotEmpty;

  static FirebaseOptions get options => FirebaseOptions(
        apiKey: apiKey,
        appId: appId,
        messagingSenderId: senderId,
        projectId: projectId,
        storageBucket: storageBucket.isEmpty ? null : storageBucket,
      );
}
