import '../models.dart';

/// One interface, two implementations: Firebase (real) and Demo (local).
abstract class Backend {
  bool get isDemo;

  Future<AppUser?> currentUser();
  Future<AppUser> signIn(String email, String password);
  Future<AppUser> register({
    required String name,
    required String email,
    required String password,
    required Role role,
  });
  Future<void> signOut();

  /// Live stream of users, projects and tasks.
  Stream<Snapshot> watch();

  /// Creates (empty id) or updates a task.
  Future<void> saveTask(TaskItem task);
  Future<void> deleteTask(String id);
  Future<void> saveProject(Project project);
}
