import 'dart:async';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

import '../models.dart';
import 'backend.dart';

/// Firebase Auth + Cloud Firestore backend.
///
/// Collections:
///   users/{uid}      name, email, role ('employee'|'manager'), weeklyHours
///   projects/{id}    name, description, start, deadline
///   tasks/{id}       title, projectId, assigneeId, progress, due, hours
class FirebaseBackend implements Backend {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _db = FirebaseFirestore.instance;

  @override
  bool get isDemo => false;

  // ---- helpers -----------------------------------------------------------

  Future<void> _write(Future<void> f) =>
      // Firestore writes only complete once the server acknowledges them. The
      // local cache already updates the UI, so do not hang when offline.
      f.timeout(const Duration(seconds: 6), onTimeout: () {});

  Map<String, dynamic> _userMap(AppUser u) => {
        'name': u.name,
        'email': u.email,
        'role': u.role == Role.manager ? 'manager' : 'employee',
        'weeklyHours': u.weeklyHours,
      };

  AppUser _userFrom(String id, Map<String, dynamic> d) => AppUser(
        id: id,
        name: (d['name'] ?? '') as String,
        email: (d['email'] ?? '') as String,
        role: d['role'] == 'manager' ? Role.manager : Role.employee,
        weeklyHours: ((d['weeklyHours'] ?? 40) as num).toInt(),
      );

  DateTime _date(dynamic v) {
    if (v is Timestamp) return v.toDate();
    return DateTime.now();
  }

  Project _projectFrom(String id, Map<String, dynamic> d) => Project(
        id: id,
        name: (d['name'] ?? '') as String,
        description: (d['description'] ?? '') as String,
        start: _date(d['start']),
        deadline: _date(d['deadline']),
      );

  TaskItem _taskFrom(String id, Map<String, dynamic> d) => TaskItem(
        id: id,
        title: (d['title'] ?? '') as String,
        projectId: (d['projectId'] ?? '') as String,
        assigneeId: (d['assigneeId'] ?? '') as String,
        progress: ((d['progress'] ?? 0) as num).toInt(),
        due: _date(d['due']),
        hours: ((d['hours'] ?? 0) as num).toDouble(),
      );

  String _authMessage(FirebaseAuthException e) {
    switch (e.code) {
      case 'invalid-email':
        return 'That email address looks invalid.';
      case 'user-not-found':
      case 'wrong-password':
      case 'invalid-credential':
        return 'Wrong email or password.';
      case 'email-already-in-use':
        return 'An account with this email already exists.';
      case 'weak-password':
        return 'Password must be at least 6 characters.';
      case 'network-request-failed':
        return 'No internet connection.';
      case 'too-many-requests':
        return 'Too many attempts. Try again later.';
      case 'operation-not-allowed':
        return 'Enable Email/Password sign-in in the Firebase console.';
      default:
        return e.message ?? 'Authentication failed.';
    }
  }

  Future<AppUser> _loadProfile(User u) async {
    final ref = _db.collection('users').doc(u.uid);
    final doc = await ref.get();
    final data = doc.data();
    if (doc.exists && data != null) {
      return _userFrom(doc.id, data);
    }
    final fallback = AppUser(
      id: u.uid,
      name: u.displayName ?? (u.email ?? 'User').split('@').first,
      email: u.email ?? '',
      role: Role.employee,
    );
    await _write(ref.set(_userMap(fallback)));
    return fallback;
  }

  // ---- auth --------------------------------------------------------------

  @override
  Future<AppUser?> currentUser() async {
    final u = _auth.currentUser;
    if (u == null) return null;
    try {
      return await _loadProfile(u);
    } catch (_) {
      return null;
    }
  }

  @override
  Future<AppUser> signIn(String email, String password) async {
    try {
      final cred = await _auth.signInWithEmailAndPassword(
          email: email.trim(), password: password);
      return await _loadProfile(cred.user!);
    } on FirebaseAuthException catch (e) {
      throw AuthFailure(_authMessage(e));
    }
  }

  @override
  Future<AppUser> register({
    required String name,
    required String email,
    required String password,
    required Role role,
  }) async {
    try {
      final cred = await _auth.createUserWithEmailAndPassword(
          email: email.trim(), password: password);
      final fbUser = cred.user!;
      final cleanName =
          name.trim().isEmpty ? email.trim().split('@').first : name.trim();
      await fbUser.updateDisplayName(cleanName);
      final user = AppUser(
        id: fbUser.uid,
        name: cleanName,
        email: email.trim(),
        role: role,
      );
      await _write(_db.collection('users').doc(user.id).set(_userMap(user)));
      return user;
    } on FirebaseAuthException catch (e) {
      throw AuthFailure(_authMessage(e));
    }
  }

  @override
  Future<void> signOut() => _auth.signOut();

  // ---- data --------------------------------------------------------------

  @override
  Stream<Snapshot> watch() {
    late StreamController<Snapshot> controller;
    final subs = <StreamSubscription<dynamic>>[];
    var users = <AppUser>[];
    var projects = <Project>[];
    var tasks = <TaskItem>[];

    void emit() {
      if (!controller.isClosed) {
        controller.add(Snapshot(users, projects, tasks));
      }
    }

    controller = StreamController<Snapshot>(
      onListen: () {
        subs.add(_db.collection('users').snapshots().listen((s) {
          users = s.docs.map((d) => _userFrom(d.id, d.data())).toList();
          emit();
        }, onError: controller.addError));
        subs.add(_db.collection('projects').snapshots().listen((s) {
          projects = s.docs.map((d) => _projectFrom(d.id, d.data())).toList();
          emit();
        }, onError: controller.addError));
        subs.add(_db.collection('tasks').snapshots().listen((s) {
          tasks = s.docs.map((d) => _taskFrom(d.id, d.data())).toList();
          emit();
        }, onError: controller.addError));
      },
      onCancel: () async {
        for (final s in subs) {
          await s.cancel();
        }
        subs.clear();
      },
    );
    return controller.stream;
  }

  @override
  Future<void> saveTask(TaskItem t) {
    final col = _db.collection('tasks');
    final ref = t.id.isEmpty ? col.doc() : col.doc(t.id);
    return _write(ref.set({
      'title': t.title,
      'projectId': t.projectId,
      'assigneeId': t.assigneeId,
      'progress': t.progress,
      'due': Timestamp.fromDate(t.due),
      'hours': t.hours,
    }));
  }

  @override
  Future<void> deleteTask(String id) =>
      _write(_db.collection('tasks').doc(id).delete());

  @override
  Future<void> saveProject(Project p) {
    final col = _db.collection('projects');
    final ref = p.id.isEmpty ? col.doc() : col.doc(p.id);
    return _write(ref.set({
      'name': p.name,
      'description': p.description,
      'start': Timestamp.fromDate(p.start),
      'deadline': Timestamp.fromDate(p.deadline),
    }));
  }
}
