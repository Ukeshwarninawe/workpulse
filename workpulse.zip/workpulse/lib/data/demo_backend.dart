import 'dart:async';

import '../models.dart';
import 'backend.dart';

/// In-memory backend with realistic sample data. Used when Firebase has not
/// been configured, so the app always runs.
class DemoBackend implements Backend {
  DemoBackend() {
    _seed();
  }

  static const demoPassword = 'demo123';
  static const managerEmail = 'manager@workpulse.demo';
  static const employeeEmail = 'rahul@workpulse.demo';

  final StreamController<Snapshot> _changes = StreamController.broadcast();
  final List<AppUser> _users = [];
  final List<Project> _projects = [];
  final List<TaskItem> _tasks = [];
  final Map<String, String> _passwords = {};
  AppUser? _me;
  int _counter = 0;

  @override
  bool get isDemo => true;

  String _newId(String prefix) =>
      '$prefix${DateTime.now().microsecondsSinceEpoch}_${_counter++}';

  Snapshot _snap() => Snapshot(
        List.unmodifiable(_users),
        List.unmodifiable(_projects),
        List.unmodifiable(_tasks),
      );

  void _notify() => _changes.add(_snap());

  void _seed() {
    final now = DateTime.now();
    DateTime inDays(int d) => now.add(Duration(days: d));

    void user(String id, String name, Role role) {
      final email = role == Role.manager
          ? managerEmail
          : '${name.toLowerCase()}@workpulse.demo';
      _users.add(AppUser(id: id, name: name, email: email, role: role));
      _passwords[email] = demoPassword;
    }

    user('u_meera', 'Meera Kulkarni', Role.manager);
    user('u_rahul', 'Rahul', Role.employee);
    user('u_aman', 'Aman', Role.employee);
    user('u_priya', 'Priya', Role.employee);
    user('u_neha', 'Neha', Role.employee);
    user('u_karan', 'Karan', Role.employee);
    user('u_sneha', 'Sneha', Role.employee);

    _projects.addAll([
      Project(
        id: 'pA',
        name: 'Project A',
        description: 'Customer mobile app',
        start: inDays(-60),
        deadline: inDays(15),
      ),
      Project(
        id: 'pB',
        name: 'Project B',
        description: 'Analytics backend',
        start: inDays(-40),
        deadline: inDays(20),
      ),
      Project(
        id: 'pC',
        name: 'Project C',
        description: 'Partner portal',
        start: inDays(-50),
        deadline: inDays(10),
      ),
    ]);

    void task(String id, String title, String project, String who, int progress,
        int dueDays, double hours) {
      _tasks.add(TaskItem(
        id: id,
        title: title,
        projectId: project,
        assigneeId: who,
        progress: progress,
        due: inDays(dueDays),
        hours: hours,
      ));
    }

    // Project A
    task('a1', 'Design system setup', 'pA', 'u_rahul', 100, -5, 20);
    task('a2', 'Onboarding screens', 'pA', 'u_priya', 100, -3, 16);
    task('a3', 'UI Design', 'pA', 'u_aman', 70, 3, 10);
    task('a4', 'Profile module', 'pA', 'u_neha', 60, 5, 8);
    task('a5', 'Push notifications', 'pA', 'u_rahul', 50, 7, 6.8);
    task('a6', 'Settings screen', 'pA', 'u_priya', 60, 10, 8);
    // Project B
    task('b1', 'Database schema', 'pB', 'u_rahul', 40, 2, 8);
    task('b2', 'API authentication', 'pB', 'u_rahul', 0, 1, 7);
    task('b3', 'Database', 'pB', 'u_aman', 50, 9, 10.4);
    task('b4', 'Reporting queries', 'pB', 'u_priya', 40, 6, 8.8);
    task('b5', 'Data export', 'pB', 'u_neha', 0, 12, 6);
    task('b6', 'ETL pipeline', 'pB', 'u_karan', 20, -2, 10);
    task('b7', 'Dashboard API', 'pB', 'u_sneha', 35, -1, 12);
    task('b8', 'Logging setup', 'pB', 'u_priya', 100, -6, 10);
    // Project C
    task('c1', 'Partner login', 'pC', 'u_rahul', 20, 2, 8);
    task('c2', 'Invoice module', 'pC', 'u_rahul', 10, 3, 7);
    task('c3', 'Testing', 'pC', 'u_aman', 30, -1, 10);
    task('c4', 'Role permissions', 'pC', 'u_karan', 30, 4, 10);
    task('c5', 'Landing page', 'pC', 'u_neha', 100, -4, 6);
  }

  @override
  Future<AppUser?> currentUser() async => _me;

  @override
  Future<AppUser> signIn(String email, String password) async {
    final key = email.trim().toLowerCase();
    final stored = _passwords[key];
    if (stored == null || stored != password) {
      throw AuthFailure(
          'Wrong email or password. Demo password is "$demoPassword".');
    }
    _me = _users.firstWhere((u) => u.email == key);
    return _me!;
  }

  @override
  Future<AppUser> register({
    required String name,
    required String email,
    required String password,
    required Role role,
  }) async {
    final key = email.trim().toLowerCase();
    if (_passwords.containsKey(key)) {
      throw AuthFailure('An account with this email already exists.');
    }
    if (password.length < 6) {
      throw AuthFailure('Password must be at least 6 characters.');
    }
    final user = AppUser(
      id: _newId('u'),
      name: name.trim().isEmpty ? key.split('@').first : name.trim(),
      email: key,
      role: role,
    );
    _users.add(user);
    _passwords[key] = password;
    _me = user;
    _notify();
    return user;
  }

  @override
  Future<void> signOut() async {
    _me = null;
  }

  @override
  Stream<Snapshot> watch() async* {
    yield _snap();
    yield* _changes.stream;
  }

  @override
  Future<void> saveTask(TaskItem task) async {
    if (task.id.isEmpty) {
      _tasks.add(TaskItem(
        id: _newId('t'),
        title: task.title,
        projectId: task.projectId,
        assigneeId: task.assigneeId,
        progress: task.progress,
        due: task.due,
        hours: task.hours,
      ));
    } else {
      final i = _tasks.indexWhere((t) => t.id == task.id);
      if (i >= 0) {
        _tasks[i] = task;
      } else {
        _tasks.add(task);
      }
    }
    _notify();
  }

  @override
  Future<void> deleteTask(String id) async {
    _tasks.removeWhere((t) => t.id == id);
    _notify();
  }

  @override
  Future<void> saveProject(Project project) async {
    if (project.id.isEmpty) {
      _projects.add(Project(
        id: _newId('p'),
        name: project.name,
        description: project.description,
        start: project.start,
        deadline: project.deadline,
      ));
    } else {
      final i = _projects.indexWhere((p) => p.id == project.id);
      if (i >= 0) {
        _projects[i] = project;
      } else {
        _projects.add(project);
      }
    }
    _notify();
  }
}
