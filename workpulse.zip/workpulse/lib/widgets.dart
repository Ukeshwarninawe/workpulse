import 'package:flutter/material.dart';

import 'analytics.dart';
import 'theme.dart';

Color levelColor(LoadLevel l) {
  switch (l) {
    case LoadLevel.high:
      return C.red;
    case LoadLevel.mid:
      return C.amber;
    case LoadLevel.low:
      return C.green;
  }
}

String levelLabel(LoadLevel l) {
  switch (l) {
    case LoadLevel.high:
      return 'HIGH';
    case LoadLevel.mid:
      return 'MID';
    case LoadLevel.low:
      return 'LOW';
  }
}

String levelNote(LoadLevel l) {
  switch (l) {
    case LoadLevel.high:
      return 'Overloaded';
    case LoadLevel.mid:
      return 'Watch';
    case LoadLevel.low:
      return 'Available';
  }
}

Color healthColor(HealthStatus s) {
  switch (s) {
    case HealthStatus.onTrack:
      return C.green;
    case HealthStatus.atRisk:
      return C.amber;
    case HealthStatus.delayed:
      return C.red;
  }
}

String healthLabel(HealthStatus s) {
  switch (s) {
    case HealthStatus.onTrack:
      return 'ON TRACK';
    case HealthStatus.atRisk:
      return 'AT RISK';
    case HealthStatus.delayed:
      return 'DELAYED';
  }
}

Color progressColor(int p) {
  if (p >= 70) return C.cyan;
  if (p >= 40) return C.purple;
  return C.amber;
}

const _months = [
  'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
  'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'
];

String fmtDate(DateTime d) => '${d.day} ${_months[d.month - 1]} ${d.year}';

String dueText(DateTime due, {bool done = false}) {
  if (done) return 'Completed';
  final now = DateTime.now();
  final today = DateTime(now.year, now.month, now.day);
  final dueDay = DateTime(due.year, due.month, due.day);
  final days = dueDay.difference(today).inDays;
  if (days < 0) return 'Overdue by ${-days} day${days == -1 ? '' : 's'}';
  if (days == 0) return 'Due today';
  if (days == 1) return 'Due tomorrow';
  return 'Due in $days days';
}

String greeting() {
  final h = DateTime.now().hour;
  if (h < 12) return 'Good morning';
  if (h < 17) return 'Good afternoon';
  return 'Good evening';
}

/// Rounded dark panel used everywhere (matches the deck's cards).
class Panel extends StatelessWidget {
  const Panel({
    super.key,
    required this.child,
    this.padding = const EdgeInsets.all(16),
    this.color = C.card,
    this.onTap,
    this.margin,
  });

  final Widget child;
  final EdgeInsetsGeometry padding;
  final Color color;
  final VoidCallback? onTap;
  final EdgeInsetsGeometry? margin;

  @override
  Widget build(BuildContext context) {
    final box = Container(
      margin: margin,
      decoration: BoxDecoration(
        color: color,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: C.line),
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          borderRadius: BorderRadius.circular(20),
          onTap: onTap,
          child: Padding(padding: padding, child: child),
        ),
      ),
    );
    return box;
  }
}

class Pill extends StatelessWidget {
  const Pill(this.text, this.color, {super.key});
  final String text;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      decoration: BoxDecoration(
        color: color,
        borderRadius: BorderRadius.circular(8),
      ),
      child: Text(
        text,
        style: const TextStyle(
          color: Color(0xFF05101A),
          fontWeight: FontWeight.w800,
          fontSize: 11,
          letterSpacing: 0.4,
        ),
      ),
    );
  }
}

class Bar extends StatelessWidget {
  const Bar({super.key, required this.value, required this.color, this.height = 8});

  /// 0..1
  final double value;
  final Color color;
  final double height;

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(height),
      child: LinearProgressIndicator(
        value: value.clamp(0.0, 1.0).toDouble(),
        minHeight: height,
        backgroundColor: C.line,
        valueColor: AlwaysStoppedAnimation<Color>(color),
      ),
    );
  }
}

class StatTile extends StatelessWidget {
  const StatTile({
    super.key,
    required this.label,
    required this.value,
    required this.color,
    this.icon,
  });

  final String label;
  final String value;
  final Color color;
  final IconData? icon;

  @override
  Widget build(BuildContext context) {
    return Panel(
      padding: const EdgeInsets.all(14),
      child: Row(
        children: [
          if (icon != null) ...[
            Icon(icon, color: color, size: 26),
            const SizedBox(width: 10),
          ],
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(label,
                    style: const TextStyle(
                        color: C.muted,
                        fontSize: 11,
                        fontWeight: FontWeight.w700,
                        letterSpacing: 0.6)),
                const SizedBox(height: 4),
                Text(value,
                    style: TextStyle(
                        color: color, fontSize: 26, fontWeight: FontWeight.w800)),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class SectionLabel extends StatelessWidget {
  const SectionLabel(this.text, {super.key, this.trailing});
  final String text;
  final Widget? trailing;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(top: 20, bottom: 10),
      child: Row(
        children: [
          Expanded(
            child: Text(
              text.toUpperCase(),
              style: const TextStyle(
                  color: C.muted,
                  fontSize: 12,
                  fontWeight: FontWeight.w800,
                  letterSpacing: 1.1),
            ),
          ),
          if (trailing != null) trailing!,
        ],
      ),
    );
  }
}

class EmptyNote extends StatelessWidget {
  const EmptyNote(this.text, {super.key});
  final String text;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(28),
      child: Center(
        child: Text(text,
            textAlign: TextAlign.center,
            style: const TextStyle(color: C.muted, fontSize: 14)),
      ),
    );
  }
}

class LogoMark extends StatelessWidget {
  const LogoMark({super.key, this.size = 44});
  final double size;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: size,
      height: size,
      alignment: Alignment.center,
      decoration: BoxDecoration(
        color: C.cyan,
        borderRadius: BorderRadius.circular(size * 0.28),
      ),
      child: Text(
        'W',
        style: TextStyle(
          color: const Color(0xFF03121C),
          fontSize: size * 0.6,
          fontWeight: FontWeight.w900,
        ),
      ),
    );
  }
}

/// Shows a snackbar when [action] throws.
Future<void> guard(BuildContext context, Future<void> Function() action) async {
  final messenger = ScaffoldMessenger.of(context);
  try {
    await action();
  } catch (e) {
    messenger.showSnackBar(SnackBar(content: Text('Something went wrong: $e')));
  }
}
