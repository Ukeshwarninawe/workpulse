import 'dart:async';

import 'package:flutter/widgets.dart';

import 'analytics.dart';
import 'data/backend.dart';
import 'models.dart';

class AppState extends ChangeNotifier {
  AppState(this.backend);

  final Backend backend;

  AppUser? me;
  Snapshot data = const Snapshot.empty();
  String? streamError;
  StreamSubscription<Snapshot>? _sub;
  Analytics? _analytics;

  bool get isDemo => backend.isDemo;

  Analytics get analytics =>
      _analytics ??= Analytics(data.users, data.projects, data.tasks);

  Future<void> init() async {
    me = await backend.currentUser();
    if (me != null) _listen();
    notifyListeners();
  }

  void _listen() {
    _sub?.cancel();
    streamError = null;
    _sub = backend.watch().listen((snap) {
      data = snap;
      _analytics = null;
      streamError = null;
      notifyListeners();
    }, onError: (Object e) {
      streamError = 'Could not load data: $e';
      notifyListeners();
    });
  }

  Future<void> signIn(String email, String password) async {
    me = await backend.signIn(email, password);
    _listen();
    notifyListeners();
  }

  Future<void> register(
      String name, String email, String password, Role role) async {
    me = await backend.register(
        name: name, email: email, password: password, role: role);
    _listen();
    notifyListeners();
  }

  Future<void> signOut() async {
    await _sub?.cancel();
    _sub = null;
    await backend.signOut();
    me = null;
    data = const Snapshot.empty();
    _analytics = null;
    notifyListeners();
  }

  // ---- lookups -----------------------------------------------------------

  AppUser? userById(String id) {
    for (final u in data.users) {
      if (u.id == id) return u;
    }
    return null;
  }

  Project? projectById(String id) {
    for (final p in data.projects) {
      if (p.id == id) return p;
    }
    return null;
  }

  List<AppUser> get employees =>
      data.users.where((u) => u.role == Role.employee).toList();

  List<TaskItem> tasksOf(String userId) =>
      data.tasks.where((t) => t.assigneeId == userId).toList()
        ..sort((a, b) => a.due.compareTo(b.due));

  // ---- actions -----------------------------------------------------------

  Future<void> saveTask(TaskItem t) => backend.saveTask(t);

  Future<void> deleteTask(String id) => backend.deleteTask(id);

  Future<void> saveProject(Project p) => backend.saveProject(p);

  Future<void> updateProgress(TaskItem t, int progress) =>
      backend.saveTask(t.copyWith(progress: progress.clamp(0, 100).toInt()));

  Future<void> reassign(TaskItem t, String newAssigneeId) =>
      backend.saveTask(t.copyWith(assigneeId: newAssigneeId));

  Future<void> applyReallocation(Reallocation r) async {
    for (final t in r.tasks) {
      await backend.saveTask(t.copyWith(assigneeId: r.to.user.id));
    }
  }

  @override
  void dispose() {
    _sub?.cancel();
    super.dispose();
  }
}

/// Gives every widget access to [AppState] and rebuilds on change.
class AppScope extends InheritedNotifier<AppState> {
  const AppScope({super.key, required AppState state, required super.child})
      : super(notifier: state);

  /// Use inside build(): rebuilds when state changes.
  static AppState of(BuildContext context) {
    final scope = context.dependOnInheritedWidgetOfExactType<AppScope>();
    assert(scope != null, 'AppScope missing above this widget');
    return scope!.notifier!;
  }

  /// Use in callbacks: does not subscribe to changes.
  static AppState read(BuildContext context) {
    final scope = context.getInheritedWidgetOfExactType<AppScope>();
    assert(scope != null, 'AppScope missing above this widget');
    return scope!.notifier!;
  }
}
