import 'package:flutter/material.dart';

/// Colour palette taken from the WorkPulse presentation.
class C {
  static const bg = Color(0xFF030B14);
  static const panel = Color(0xFF08121F);
  static const card = Color(0xFF121D31);
  static const line = Color(0xFF22324D);
  static const cyan = Color(0xFF38D0FF);
  static const purple = Color(0xFF8B6CFF);
  static const amber = Color(0xFFF7B84B);
  static const red = Color(0xFFFF5470);
  static const green = Color(0xFF3AD28B);
  static const text = Color(0xFFEAF1FB);
  static const muted = Color(0xFF8EA0B8);
}

ThemeData buildTheme() {
  final base = ThemeData.dark(useMaterial3: true);
  return base.copyWith(
    scaffoldBackgroundColor: C.bg,
    colorScheme: const ColorScheme.dark(
      primary: C.cyan,
      onPrimary: Color(0xFF03121C),
      secondary: C.purple,
      surface: C.panel,
      error: C.red,
    ),
    appBarTheme: const AppBarTheme(
      backgroundColor: C.bg,
      surfaceTintColor: Colors.transparent,
      elevation: 0,
      centerTitle: false,
      titleTextStyle: TextStyle(
        color: C.text,
        fontSize: 20,
        fontWeight: FontWeight.w800,
      ),
    ),
    navigationBarTheme: const NavigationBarThemeData(
      backgroundColor: C.panel,
      surfaceTintColor: Colors.transparent,
      indicatorColor: Color(0xFF16324A),
    ),
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: C.card,
      labelStyle: const TextStyle(color: C.muted),
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(14),
        borderSide: const BorderSide(color: C.line),
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(14),
        borderSide: const BorderSide(color: C.line),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(14),
        borderSide: const BorderSide(color: C.cyan, width: 1.5),
      ),
    ),
    snackBarTheme: const SnackBarThemeData(behavior: SnackBarBehavior.floating),
  );
}
