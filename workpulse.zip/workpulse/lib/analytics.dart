import 'models.dart';

/// Workload thresholds (matches the deck: 92% high, 76% mid, 42% low).
enum LoadLevel { high, mid, low }

LoadLevel levelFor(double percent) {
  if (percent >= 85) return LoadLevel.high;
  if (percent >= 60) return LoadLevel.mid;
  return LoadLevel.low;
}

enum HealthStatus { onTrack, atRisk, delayed }

enum AlertKind { critical, warning, ok }

class EmployeeLoad {
  EmployeeLoad({
    required this.user,
    required this.percent,
    required this.active,
    required this.dueSoon,
    required this.overdue,
    required this.completed,
  });

  final AppUser user;
  final double percent;
  final int active;
  final int dueSoon;
  final int overdue;
  final int completed;

  LoadLevel get level => levelFor(percent);
}

class ProjectHealth {
  ProjectHealth({
    required this.project,
    required this.progress,
    required this.expected,
    required this.status,
    required this.overdue,
    required this.taskCount,
  });

  final Project project;

  /// 0..100, effort-weighted average of task progress.
  final double progress;

  /// 0..100, how far along the calendar says the project should be.
  final double expected;
  final HealthStatus status;
  final int overdue;
  final int taskCount;
}

class AlertItem {
  AlertItem(this.kind, this.text);
  final AlertKind kind;
  final String text;
}

class Reallocation {
  Reallocation({required this.from, required this.to, required this.tasks});
  final EmployeeLoad from;
  final EmployeeLoad to;
  final List<TaskItem> tasks;
}

/// Turns raw users / projects / tasks into workload intelligence.
class Analytics {
  Analytics(this.users, this.projects, this.tasks, {DateTime? now})
      : now = now ?? DateTime.now();

  final List<AppUser> users;
  final List<Project> projects;
  final List<TaskItem> tasks;
  final DateTime now;

  bool isOverdue(TaskItem t) => !t.done && t.due.isBefore(now);

  bool isDueSoon(TaskItem t) =>
      !t.done && !isOverdue(t) && t.due.difference(now) <= const Duration(days: 3);

  late final List<EmployeeLoad> loads = _buildLoads();

  List<EmployeeLoad> _buildLoads() {
    final result = <EmployeeLoad>[];
    for (final u in users) {
      if (u.role != Role.employee) continue;
      final mine = tasks.where((t) => t.assigneeId == u.id).toList();
      final active = mine.where((t) => !t.done).toList();
      final hours = active.fold<double>(0, (s, t) => s + t.hours);
      final cap = u.weeklyHours <= 0 ? 40 : u.weeklyHours;
      result.add(EmployeeLoad(
        user: u,
        percent: hours / cap * 100,
        active: active.length,
        dueSoon: active.where(isDueSoon).length,
        overdue: active.where(isOverdue).length,
        completed: mine.length - active.length,
      ));
    }
    result.sort((a, b) => b.percent.compareTo(a.percent));
    return result;
  }

  EmployeeLoad? loadOf(String userId) {
    for (final l in loads) {
      if (l.user.id == userId) return l;
    }
    return null;
  }

  /// Average team workload, 0..100.
  double get teamCapacity {
    if (loads.isEmpty) return 0;
    final avg = loads.fold<double>(0, (s, l) => s + l.percent) / loads.length;
    return avg.clamp(0.0, 100.0).toDouble();
  }

  int get overloadedCount =>
      loads.where((l) => l.level == LoadLevel.high).length;

  int get availableCount => loads.where((l) => l.level == LoadLevel.low).length;

  int get atRiskCount => loads
      .where((l) =>
          l.level != LoadLevel.high &&
          (l.level == LoadLevel.mid || l.overdue > 0 || l.dueSoon >= 3))
      .length;

  int get activeTaskCount => tasks.where((t) => !t.done).length;

  late final List<ProjectHealth> health = _buildHealth();

  List<ProjectHealth> _buildHealth() {
    final result = <ProjectHealth>[];
    for (final p in projects) {
      final pt = tasks.where((t) => t.projectId == p.id).toList();
      final total = pt.fold<double>(0, (s, t) => s + t.hours);
      final progress = total == 0
          ? 0.0
          : pt.fold<double>(0, (s, t) => s + t.hours * t.progress) / total;
      final span = p.deadline.difference(p.start).inHours;
      final elapsed = now.difference(p.start).inHours;
      final expected = span <= 0
          ? 100.0
          : (elapsed / span * 100).clamp(0.0, 100.0).toDouble();
      final overdue = pt.where(isOverdue).length;
      final gap = expected - progress;

      HealthStatus status;
      if (progress >= 100) {
        status = HealthStatus.onTrack;
      } else if (gap > 30) {
        status = HealthStatus.delayed;
      } else if (gap > 10 || overdue >= 2) {
        status = HealthStatus.atRisk;
      } else {
        status = HealthStatus.onTrack;
      }
      result.add(ProjectHealth(
        project: p,
        progress: progress,
        expected: expected,
        status: status,
        overdue: overdue,
        taskCount: pt.length,
      ));
    }
    return result;
  }

  ProjectHealth? healthOf(String projectId) {
    for (final h in health) {
      if (h.project.id == projectId) return h;
    }
    return null;
  }

  late final List<AlertItem> alerts = _buildAlerts();

  List<AlertItem> _buildAlerts() {
    final critical = <AlertItem>[];
    final warning = <AlertItem>[];
    final ok = <AlertItem>[];

    for (final l in loads) {
      final name = l.user.firstName;
      if (l.level == LoadLevel.high) {
        critical.add(AlertItem(AlertKind.critical,
            '$name is overloaded at ${l.percent.round()}% capacity.'));
      }
      if (l.dueSoon >= 2) {
        warning.add(AlertItem(AlertKind.warning,
            '$name has ${l.dueSoon} tasks approaching deadline.'));
      }
      if (l.overdue > 0) {
        warning.add(AlertItem(AlertKind.warning,
            '$name has ${l.overdue} overdue task${l.overdue == 1 ? '' : 's'}.'));
      }
      if (l.level == LoadLevel.low && l.overdue == 0) {
        ok.add(AlertItem(AlertKind.ok, '$name has available capacity.'));
      }
    }

    for (final h in health) {
      final name = h.project.name;
      if (h.status == HealthStatus.delayed) {
        critical.add(AlertItem(AlertKind.critical,
            '$name is delayed (${h.progress.round()}% done, ${h.expected.round()}% expected).'));
      }
      if (h.overdue >= 2) {
        critical.add(
            AlertItem(AlertKind.critical, '$name has multiple overdue tasks.'));
      } else if (h.status == HealthStatus.atRisk) {
        warning.add(AlertItem(AlertKind.warning, '$name is at risk of slipping.'));
      }
    }
    return [...critical, ...warning, ...ok];
  }

  /// Suggest moving the least-started tasks from the most loaded person to
  /// the least loaded one.
  Reallocation? get suggestion {
    if (loads.length < 2) return null;
    final from = loads.first;
    final to = loads.last;
    if (from.level != LoadLevel.high) return null;
    if (to.user.id == from.user.id || to.level == LoadLevel.high) return null;

    final movable = tasks
        .where((t) => t.assigneeId == from.user.id && !t.done)
        .toList()
      ..sort((a, b) => a.progress.compareTo(b.progress));
    if (movable.isEmpty) return null;
    return Reallocation(
      from: from,
      to: to,
      tasks: movable.take(2).toList(),
    );
  }
}
