import 'package:flutter/material.dart';

import '../analytics.dart';
import '../app_state.dart';
import '../dialogs.dart';
import '../models.dart';
import '../theme.dart';
import '../widgets.dart';

/// One workload row: name, bar, %, level pill (Team Workload in the deck).
class LoadRow extends StatelessWidget {
  const LoadRow({super.key, required this.load, this.onTap});
  final EmployeeLoad load;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    final color = levelColor(load.level);
    return InkWell(
      borderRadius: BorderRadius.circular(12),
      onTap: onTap,
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 9),
        child: Row(
          children: [
            SizedBox(
              width: 64,
              child: Text(load.user.firstName,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                      color: C.text, fontWeight: FontWeight.w800)),
            ),
            Expanded(child: Bar(value: load.percent / 100, color: color)),
            SizedBox(
              width: 52,
              child: Text('${load.percent.round()}%',
                  textAlign: TextAlign.right,
                  style: TextStyle(color: color, fontWeight: FontWeight.w800)),
            ),
            const SizedBox(width: 8),
            SizedBox(
                width: 60,
                child: Center(child: Pill(levelLabel(load.level), color))),
          ],
        ),
      ),
    );
  }
}

class TaskTile extends StatelessWidget {
  const TaskTile({
    super.key,
    required this.task,
    this.onTap,
    this.showAssignee = false,
    this.trailing,
  });

  final TaskItem task;
  final VoidCallback? onTap;
  final bool showAssignee;
  final Widget? trailing;

  @override
  Widget build(BuildContext context) {
    final state = AppScope.of(context);
    final project = state.projectById(task.projectId);
    final assignee = state.userById(task.assigneeId);
    final overdue = !task.done && task.due.isBefore(DateTime.now());
    final color = task.done ? C.green : progressColor(task.progress);

    final meta = <String>[
      if (project != null) project.name,
      if (showAssignee && assignee != null) assignee.firstName,
      '${task.hours.toStringAsFixed(task.hours % 1 == 0 ? 0 : 1)}h',
    ].join(' • ');

    return Panel(
      margin: const EdgeInsets.only(bottom: 10),
      onTap: onTap,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: Text(task.title,
                    style: TextStyle(
                        color: C.text,
                        fontSize: 15,
                        fontWeight: FontWeight.w800,
                        decoration:
                            task.done ? TextDecoration.lineThrough : null)),
              ),
              Text('${task.progress}%',
                  style: TextStyle(color: color, fontWeight: FontWeight.w800)),
              if (trailing != null) trailing!,
            ],
          ),
          const SizedBox(height: 4),
          Text(meta, style: const TextStyle(color: C.muted, fontSize: 12)),
          const SizedBox(height: 10),
          Bar(value: task.progress / 100, color: color),
          const SizedBox(height: 8),
          Text(dueText(task.due, done: task.done),
              style: TextStyle(
                  color: overdue ? C.red : C.muted,
                  fontSize: 12,
                  fontWeight: overdue ? FontWeight.w800 : FontWeight.w500)),
        ],
      ),
    );
  }
}

/// Team workload list, read-only (used by employees and managers).
class TeamTab extends StatelessWidget {
  const TeamTab({super.key, this.managerView = false});
  final bool managerView;

  @override
  Widget build(BuildContext context) {
    final state = AppScope.of(context);
    final a = state.analytics;
    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 4, 16, 24),
      children: [
        Row(
          children: [
            Expanded(
                child: StatTile(
                    label: 'TEAM CAPACITY',
                    value: '${a.teamCapacity.round()}%',
                    color: C.cyan,
                    icon: Icons.groups_outlined)),
            const SizedBox(width: 12),
            Expanded(
                child: StatTile(
                    label: 'AVAILABLE',
                    value: a.availableCount.toString().padLeft(2, '0'),
                    color: C.green,
                    icon: Icons.check_circle_outline)),
          ],
        ),
        const SectionLabel('Workload distribution'),
        if (a.loads.isEmpty)
          const EmptyNote('No employees yet. Ask people to create an account.')
        else
          Panel(
            child: Column(
              children: [
                for (final l in a.loads)
                  LoadRow(
                    load: l,
                    onTap: managerView
                        ? () => showPersonSheet(context, l.user.id)
                        : null,
                  ),
              ],
            ),
          ),
        if (managerView && a.loads.isNotEmpty)
          const Padding(
            padding: EdgeInsets.only(top: 12),
            child: Text('Tap a person to see and reassign their tasks.',
                textAlign: TextAlign.center,
                style: TextStyle(color: C.muted, fontSize: 12)),
          ),
      ],
    );
  }
}

/// Manager: a person's open tasks, each reassignable.
Future<void> showPersonSheet(BuildContext context, String userId) {
  return showModalBottomSheet<void>(
    context: context,
    backgroundColor: C.panel,
    isScrollControlled: true,
    builder: (ctx) {
      final state = AppScope.of(ctx);
      final user = state.userById(userId);
      final load = state.analytics.loadOf(userId);
      final tasks = state.tasksOf(userId).where((t) => !t.done).toList();
      return DraggableScrollableSheet(
        expand: false,
        initialChildSize: 0.7,
        maxChildSize: 0.95,
        builder: (ctx, scroll) => ListView(
          controller: scroll,
          padding: const EdgeInsets.all(20),
          children: [
            Text(user?.name ?? 'Employee',
                style: const TextStyle(
                    color: C.text, fontSize: 20, fontWeight: FontWeight.w800)),
            if (load != null) ...[
              const SizedBox(height: 4),
              Text(
                  '${load.percent.round()}% workload • ${levelNote(load.level)} • ${load.overdue} overdue',
                  style: TextStyle(color: levelColor(load.level))),
              const SizedBox(height: 12),
              Bar(
                  value: load.percent / 100,
                  color: levelColor(load.level),
                  height: 10),
            ],
            const SectionLabel('Open tasks'),
            if (tasks.isEmpty) const EmptyNote('No open tasks.'),
            for (final t in tasks)
              TaskTile(
                task: t,
                trailing: IconButton(
                  tooltip: 'Reassign',
                  icon: const Icon(Icons.swap_horiz, color: C.cyan),
                  onPressed: () {
                    Navigator.pop(ctx);
                    showReassignSheet(context, t);
                  },
                ),
              ),
          ],
        ),
      );
    },
  );
}

class ProfileTab extends StatelessWidget {
  const ProfileTab({super.key});

  @override
  Widget build(BuildContext context) {
    final state = AppScope.of(context);
    final me = state.me;
    if (me == null) return const SizedBox.shrink();
    final load = state.analytics.loadOf(me.id);
    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
      children: [
        Panel(
          child: Row(
            children: [
              CircleAvatar(
                radius: 30,
                backgroundColor: C.purple,
                child: Text(
                  me.name.isEmpty ? '?' : me.name.trim()[0].toUpperCase(),
                  style: const TextStyle(
                      fontSize: 26,
                      fontWeight: FontWeight.w900,
                      color: Color(0xFF0B0620)),
                ),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(me.name,
                        style: const TextStyle(
                            color: C.text,
                            fontSize: 18,
                            fontWeight: FontWeight.w800)),
                    const SizedBox(height: 2),
                    Text(me.email,
                        style: const TextStyle(color: C.muted, fontSize: 13)),
                    const SizedBox(height: 8),
                    Pill(me.role == Role.manager ? 'MANAGER' : 'EMPLOYEE',
                        me.role == Role.manager ? C.purple : C.cyan),
                  ],
                ),
              ),
            ],
          ),
        ),
        const SectionLabel('Details'),
        Panel(
          child: Column(
            children: [
              _kv('Weekly capacity', '${me.weeklyHours} hours'),
              if (load != null) ...[
                _kv('Current workload', '${load.percent.round()}%'),
                _kv('Open tasks', '${load.active}'),
                _kv('Completed tasks', '${load.completed}'),
              ],
              _kv('Data source',
                  state.isDemo ? 'Demo (local sample data)' : 'Firebase (live)'),
            ],
          ),
        ),
        const SizedBox(height: 20),
        OutlinedButton.icon(
          style: OutlinedButton.styleFrom(
              minimumSize: const Size.fromHeight(50),
              foregroundColor: C.red,
              side: const BorderSide(color: C.red)),
          icon: const Icon(Icons.logout),
          label: const Text('Sign out'),
          onPressed: () => guard(context, state.signOut),
        ),
      ],
    );
  }

  Widget _kv(String k, String v) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 8),
        child: Row(
          children: [
            Expanded(
                child: Text(k, style: const TextStyle(color: C.muted))),
            Text(v,
                style: const TextStyle(
                    color: C.text, fontWeight: FontWeight.w700)),
          ],
        ),
      );
}
