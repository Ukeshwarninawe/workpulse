import 'package:flutter/material.dart';

import '../analytics.dart';
import '../app_state.dart';
import '../dialogs.dart';
import '../theme.dart';
import '../widgets.dart';
import 'common_tabs.dart';

class ManagerShell extends StatefulWidget {
  const ManagerShell({super.key});

  @override
  State<ManagerShell> createState() => _ManagerShellState();
}

class _ManagerShellState extends State<ManagerShell> {
  int _index = 0;

  @override
  Widget build(BuildContext context) {
    final state = AppScope.of(context);
    final alertCount = state.analytics.alerts
        .where((a) => a.kind != AlertKind.ok)
        .length;

    const titles = ['Manager Dashboard', 'Team Workload', 'Projects', 'Smart Alerts', 'Profile'];
    final tabs = <Widget>[
      const _Dashboard(),
      const TeamTab(managerView: true),
      const _ProjectsTab(),
      const _AlertsTab(),
      const ProfileTab(),
    ];

    return Scaffold(
      appBar: AppBar(
        title: Row(
          children: [
            if (_index == 0) ...[const LogoMark(size: 30), const SizedBox(width: 10)],
            Flexible(child: Text(titles[_index], overflow: TextOverflow.ellipsis)),
          ],
        ),
        actions: [
          IconButton(
            tooltip: 'Profile',
            icon: Icon(_index == 4 ? Icons.person : Icons.person_outline),
            onPressed: () => setState(() => _index = 4),
          ),
        ],
      ),
      body: Column(
        children: [
          if (state.streamError != null)
            Container(
              width: double.infinity,
              color: const Color(0xFF3A1620),
              padding: const EdgeInsets.all(10),
              child: Text(state.streamError!,
                  style: const TextStyle(color: C.red, fontSize: 12)),
            ),
          Expanded(child: tabs[_index]),
        ],
      ),
      floatingActionButton: _index == 4
          ? null
          : FloatingActionButton.extended(
              backgroundColor: C.cyan,
              foregroundColor: const Color(0xFF03121C),
              icon: const Icon(Icons.add_task),
              label: const Text('Assign task'),
              onPressed: () {
                if (state.data.projects.isEmpty) {
                  showProjectEditor(context);
                } else {
                  showTaskEditor(context);
                }
              },
            ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _index > 3 ? 0 : _index,
        onDestinationSelected: (i) => setState(() => _index = i),
        destinations: [
          const NavigationDestination(
              icon: Icon(Icons.dashboard_outlined),
              selectedIcon: Icon(Icons.dashboard, color: C.cyan),
              label: 'Dashboard'),
          const NavigationDestination(
              icon: Icon(Icons.groups_outlined),
              selectedIcon: Icon(Icons.groups, color: C.cyan),
              label: 'Team'),
          const NavigationDestination(
              icon: Icon(Icons.folder_outlined),
              selectedIcon: Icon(Icons.folder, color: C.cyan),
              label: 'Projects'),
          NavigationDestination(
              icon: Badge(
                  isLabelVisible: alertCount > 0,
                  label: Text('$alertCount'),
                  child: const Icon(Icons.notifications_outlined)),
              selectedIcon: const Icon(Icons.notifications, color: C.cyan),
              label: 'Alerts'),
        ],
      ),
    );
  }
}

class _Dashboard extends StatelessWidget {
  const _Dashboard();

  @override
  Widget build(BuildContext context) {
    final state = AppScope.of(context);
    final a = state.analytics;
    final suggestion = a.suggestion;

    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 0, 16, 96),
      children: [
        const Text('A live team view turns workload data into decisions.',
            style: TextStyle(color: C.muted)),
        const SizedBox(height: 14),
        Row(
          children: [
            Expanded(
                child: StatTile(
                    label: 'CAPACITY',
                    value: '${a.teamCapacity.round()}%',
                    color: C.cyan,
                    icon: Icons.groups_outlined)),
            const SizedBox(width: 12),
            Expanded(
                child: StatTile(
                    label: 'AT RISK',
                    value: a.atRiskCount.toString().padLeft(2, '0'),
                    color: C.amber,
                    icon: Icons.warning_amber_rounded)),
          ],
        ),
        const SizedBox(height: 12),
        Row(
          children: [
            Expanded(
                child: StatTile(
                    label: 'OVERLOAD',
                    value: a.overloadedCount.toString().padLeft(2, '0'),
                    color: C.red,
                    icon: Icons.speed)),
            const SizedBox(width: 12),
            Expanded(
                child: StatTile(
                    label: 'AVAILABLE',
                    value: a.availableCount.toString().padLeft(2, '0'),
                    color: C.green,
                    icon: Icons.check_circle_outline)),
          ],
        ),
        const SectionLabel('Team workload'),
        Panel(
          child: a.loads.isEmpty
              ? const EmptyNote('No employees yet.')
              : Column(
                  children: [
                    for (final l in a.loads)
                      LoadRow(
                          load: l,
                          onTap: () => showPersonSheet(context, l.user.id)),
                  ],
                ),
        ),
        const SectionLabel('Manager action'),
        Panel(
          child: suggestion == null
              ? const Row(
                  children: [
                    Icon(Icons.check_circle, color: C.green),
                    SizedBox(width: 12),
                    Expanded(
                      child: Text('Workload is balanced. No reallocation needed.',
                          style: TextStyle(color: C.text)),
                    ),
                  ],
                )
              : Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                        'Reallocate ${suggestion.tasks.length} task${suggestion.tasks.length == 1 ? '' : 's'}\nfrom ${suggestion.from.user.firstName} → ${suggestion.to.user.firstName}',
                        style: const TextStyle(
                            color: C.text,
                            fontSize: 18,
                            height: 1.25,
                            fontWeight: FontWeight.w800)),
                    const SizedBox(height: 6),
                    Text(
                        '${suggestion.from.user.firstName} is at ${suggestion.from.percent.round()}%, ${suggestion.to.user.firstName} at ${suggestion.to.percent.round()}%.',
                        style: const TextStyle(color: C.muted, fontSize: 13)),
                    const SizedBox(height: 14),
                    FilledButton(
                      onPressed: () =>
                          showReallocationDialog(context, suggestion),
                      child: const Text('REVIEW'),
                    ),
                  ],
                ),
        ),
        const SectionLabel('Project health'),
        if (a.health.isEmpty)
          const EmptyNote('No projects yet. Tap "Assign task" to create one.')
        else
          for (final h in a.health) _ProjectCard(h: h),
      ],
    );
  }
}

class _ProjectCard extends StatelessWidget {
  const _ProjectCard({required this.h});
  final ProjectHealth h;

  @override
  Widget build(BuildContext context) {
    final color = healthColor(h.status);
    return Panel(
      margin: const EdgeInsets.only(bottom: 10),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: Text(h.project.name,
                    style: const TextStyle(
                        color: C.text,
                        fontSize: 16,
                        fontWeight: FontWeight.w800)),
              ),
              Text('${h.progress.round()}%',
                  style: TextStyle(color: color, fontWeight: FontWeight.w800)),
            ],
          ),
          if (h.project.description.isNotEmpty) ...[
            const SizedBox(height: 2),
            Text(h.project.description,
                style: const TextStyle(color: C.muted, fontSize: 12)),
          ],
          const SizedBox(height: 10),
          Bar(value: h.progress / 100, color: color),
          const SizedBox(height: 12),
          Row(
            children: [
              Pill(healthLabel(h.status), color),
              const Spacer(),
              Text(
                  '${h.taskCount} tasks • ${h.overdue} overdue • due ${fmtDate(h.project.deadline)}',
                  style: const TextStyle(color: C.muted, fontSize: 11)),
            ],
          ),
        ],
      ),
    );
  }
}

class _ProjectsTab extends StatelessWidget {
  const _ProjectsTab();

  @override
  Widget build(BuildContext context) {
    final state = AppScope.of(context);
    final a = state.analytics;
    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 0, 16, 96),
      children: [
        const Text('Managers see risk before it becomes a deadline failure.',
            style: TextStyle(color: C.muted)),
        SectionLabel('${a.health.length} projects',
            trailing: TextButton.icon(
              onPressed: () => showProjectEditor(context),
              icon: const Icon(Icons.add, size: 18),
              label: const Text('New project'),
            )),
        if (a.health.isEmpty)
          const EmptyNote('No projects yet.')
        else
          for (final h in a.health)
            _ProjectWithTasks(h: h),
      ],
    );
  }
}

class _ProjectWithTasks extends StatelessWidget {
  const _ProjectWithTasks({required this.h});
  final ProjectHealth h;

  @override
  Widget build(BuildContext context) {
    final state = AppScope.of(context);
    final tasks = state.data.tasks
        .where((t) => t.projectId == h.project.id)
        .toList()
      ..sort((a, b) => a.due.compareTo(b.due));
    return Theme(
      data: Theme.of(context).copyWith(dividerColor: Colors.transparent),
      child: Container(
        margin: const EdgeInsets.only(bottom: 10),
        decoration: BoxDecoration(
          color: C.card,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: C.line),
        ),
        child: ExpansionTile(
          tilePadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
          childrenPadding: const EdgeInsets.fromLTRB(12, 0, 12, 12),
          shape: const RoundedRectangleBorder(
              borderRadius: BorderRadius.all(Radius.circular(20))),
          collapsedShape: const RoundedRectangleBorder(
              borderRadius: BorderRadius.all(Radius.circular(20))),
          title: _ProjectHeader(h: h),
          children: [
            if (tasks.isEmpty) const EmptyNote('No tasks in this project yet.'),
            for (final t in tasks)
              TaskTile(
                task: t,
                showAssignee: true,
                onTap: () => showTaskEditor(context, existing: t),
                trailing: t.done
                    ? null
                    : IconButton(
                        tooltip: 'Reassign',
                        icon: const Icon(Icons.swap_horiz, color: C.cyan),
                        onPressed: () => showReassignSheet(context, t),
                      ),
              ),
          ],
        ),
      ),
    );
  }
}

class _ProjectHeader extends StatelessWidget {
  const _ProjectHeader({required this.h});
  final ProjectHealth h;

  @override
  Widget build(BuildContext context) {
    final color = healthColor(h.status);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Expanded(
              child: Text(h.project.name,
                  style: const TextStyle(
                      color: C.text, fontSize: 16, fontWeight: FontWeight.w800)),
            ),
            Text('${h.progress.round()}%',
                style: TextStyle(color: color, fontWeight: FontWeight.w800)),
          ],
        ),
        const SizedBox(height: 10),
        Bar(value: h.progress / 100, color: color),
        const SizedBox(height: 10),
        Row(
          children: [
            Pill(healthLabel(h.status), color),
            const SizedBox(width: 10),
            Expanded(
              child: Text('due ${fmtDate(h.project.deadline)}',
                  style: const TextStyle(color: C.muted, fontSize: 11)),
            ),
          ],
        ),
      ],
    );
  }
}

class _AlertsTab extends StatelessWidget {
  const _AlertsTab();

  @override
  Widget build(BuildContext context) {
    final state = AppScope.of(context);
    final alerts = state.analytics.alerts;
    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 0, 16, 96),
      children: [
        const Text('Early signals → faster action.',
            style: TextStyle(color: C.purple, fontWeight: FontWeight.w800)),
        const SizedBox(height: 12),
        if (alerts.isEmpty)
          const EmptyNote('No alerts. Everything looks healthy.')
        else
          for (final al in alerts)
            Panel(
              margin: const EdgeInsets.only(bottom: 10),
              child: Row(
                children: [
                  Icon(_icon(al.kind), color: _color(al.kind)),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Text(al.text,
                        style: const TextStyle(color: C.text, height: 1.3)),
                  ),
                ],
              ),
            ),
      ],
    );
  }

  IconData _icon(AlertKind k) {
    switch (k) {
      case AlertKind.critical:
        return Icons.error_outline;
      case AlertKind.warning:
        return Icons.warning_amber_rounded;
      case AlertKind.ok:
        return Icons.check_circle_outline;
    }
  }

  Color _color(AlertKind k) {
    switch (k) {
      case AlertKind.critical:
        return C.red;
      case AlertKind.warning:
        return C.amber;
      case AlertKind.ok:
        return C.green;
    }
  }
}
