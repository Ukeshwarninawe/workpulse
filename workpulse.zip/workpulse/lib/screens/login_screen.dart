import 'package:flutter/material.dart';

import '../app_state.dart';
import '../data/demo_backend.dart';
import '../models.dart';
import '../theme.dart';
import '../widgets.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _name = TextEditingController();
  final _email = TextEditingController();
  final _password = TextEditingController();
  bool _register = false;
  Role _role = Role.employee;
  bool _busy = false;
  String? _error;

  @override
  void dispose() {
    _name.dispose();
    _email.dispose();
    _password.dispose();
    super.dispose();
  }

  Future<void> _run(Future<void> Function(AppState s) action) async {
    final state = AppScope.read(context);
    setState(() {
      _busy = true;
      _error = null;
    });
    try {
      await action(state);
    } on AuthFailure catch (e) {
      if (mounted) setState(() => _error = e.message);
    } catch (e) {
      if (mounted) setState(() => _error = 'Something went wrong: $e');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  void _submit() {
    final email = _email.text.trim();
    final pass = _password.text;
    if (email.isEmpty || pass.isEmpty) {
      setState(() => _error = 'Enter your email and password.');
      return;
    }
    _run((s) => _register
        ? s.register(_name.text, email, pass, _role)
        : s.signIn(email, pass));
  }

  @override
  Widget build(BuildContext context) {
    final state = AppScope.of(context);
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 440),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      const LogoMark(),
                      const SizedBox(width: 12),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: const [
                          Text('WORKPULSE',
                              style: TextStyle(
                                  color: C.text,
                                  fontSize: 22,
                                  fontWeight: FontWeight.w900,
                                  letterSpacing: 1.5)),
                          Text('WORKFORCE INTELLIGENCE',
                              style: TextStyle(
                                  color: C.purple,
                                  fontSize: 10,
                                  fontWeight: FontWeight.w700,
                                  letterSpacing: 1.8)),
                        ],
                      ),
                    ],
                  ),
                  const SizedBox(height: 36),
                  const Text('Employee Workload &\nResource Allocation',
                      style: TextStyle(
                          color: C.cyan,
                          fontSize: 26,
                          height: 1.15,
                          fontWeight: FontWeight.w800)),
                  const SizedBox(height: 8),
                  const Text('“Right Work. Right People. Right Time.”',
                      style: TextStyle(
                          color: C.muted,
                          fontSize: 15,
                          fontStyle: FontStyle.italic)),
                  const SizedBox(height: 28),
                  Panel(
                    padding: const EdgeInsets.all(18),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(_register ? 'Create account' : 'Sign in',
                            style: const TextStyle(
                                color: C.text,
                                fontSize: 18,
                                fontWeight: FontWeight.w800)),
                        const SizedBox(height: 16),
                        if (_register) ...[
                          TextField(
                            controller: _name,
                            textCapitalization: TextCapitalization.words,
                            decoration:
                                const InputDecoration(labelText: 'Full name'),
                          ),
                          const SizedBox(height: 12),
                        ],
                        TextField(
                          controller: _email,
                          keyboardType: TextInputType.emailAddress,
                          autocorrect: false,
                          decoration: const InputDecoration(labelText: 'Email'),
                        ),
                        const SizedBox(height: 12),
                        TextField(
                          controller: _password,
                          obscureText: true,
                          onSubmitted: (_) => _submit(),
                          decoration:
                              const InputDecoration(labelText: 'Password'),
                        ),
                        if (_register) ...[
                          const SizedBox(height: 16),
                          SegmentedButton<Role>(
                            segments: const [
                              ButtonSegment(
                                  value: Role.employee,
                                  label: Text('Employee'),
                                  icon: Icon(Icons.person_outline)),
                              ButtonSegment(
                                  value: Role.manager,
                                  label: Text('Manager'),
                                  icon: Icon(Icons.groups_outlined)),
                            ],
                            selected: {_role},
                            onSelectionChanged: (s) =>
                                setState(() => _role = s.first),
                          ),
                        ],
                        if (_error != null) ...[
                          const SizedBox(height: 12),
                          Text(_error!, style: const TextStyle(color: C.red)),
                        ],
                        const SizedBox(height: 18),
                        FilledButton(
                          style: FilledButton.styleFrom(
                              minimumSize: const Size.fromHeight(52)),
                          onPressed: _busy ? null : _submit,
                          child: _busy
                              ? const SizedBox(
                                  width: 20,
                                  height: 20,
                                  child:
                                      CircularProgressIndicator(strokeWidth: 2))
                              : Text(_register ? 'Create account' : 'Sign in'),
                        ),
                        Align(
                          alignment: Alignment.center,
                          child: TextButton(
                            onPressed: _busy
                                ? null
                                : () => setState(() {
                                      _register = !_register;
                                      _error = null;
                                    }),
                            child: Text(_register
                                ? 'Already have an account? Sign in'
                                : 'New here? Create an account'),
                          ),
                        ),
                      ],
                    ),
                  ),
                  if (state.isDemo) ...[
                    const SizedBox(height: 20),
                    Panel(
                      color: C.panel,
                      padding: const EdgeInsets.all(16),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Row(
                            children: [
                              Icon(Icons.science_outlined,
                                  color: C.amber, size: 18),
                              SizedBox(width: 8),
                              Text('DEMO MODE',
                                  style: TextStyle(
                                      color: C.amber,
                                      fontWeight: FontWeight.w800,
                                      letterSpacing: 1)),
                            ],
                          ),
                          const SizedBox(height: 6),
                          const Text(
                              'Firebase is not configured, so the app uses local sample data. Try it instantly:',
                              style: TextStyle(color: C.muted, fontSize: 13)),
                          const SizedBox(height: 12),
                          Row(
                            children: [
                              Expanded(
                                child: OutlinedButton.icon(
                                  icon: const Icon(Icons.dashboard_outlined,
                                      size: 18),
                                  label: const Text('Manager'),
                                  onPressed: _busy
                                      ? null
                                      : () => _run((s) => s.signIn(
                                          DemoBackend.managerEmail,
                                          DemoBackend.demoPassword)),
                                ),
                              ),
                              const SizedBox(width: 12),
                              Expanded(
                                child: OutlinedButton.icon(
                                  icon: const Icon(Icons.person_outline,
                                      size: 18),
                                  label: const Text('Employee'),
                                  onPressed: _busy
                                      ? null
                                      : () => _run((s) => s.signIn(
                                          DemoBackend.employeeEmail,
                                          DemoBackend.demoPassword)),
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ],
                  const SizedBox(height: 16),
                  const Center(
                    child: Text('Flutter + Firebase • Workforce Management',
                        style: TextStyle(color: C.muted, fontSize: 12)),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
