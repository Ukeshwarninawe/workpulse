import 'package:flutter/material.dart';

import '../analytics.dart';
import '../app_state.dart';
import '../dialogs.dart';
import '../theme.dart';
import '../widgets.dart';
import 'common_tabs.dart';

class EmployeeShell extends StatefulWidget {
  const EmployeeShell({super.key});

  @override
  State<EmployeeShell> createState() => _EmployeeShellState();
}

class _EmployeeShellState extends State<EmployeeShell> {
  int _index = 0;

  @override
  Widget build(BuildContext context) {
    final state = AppScope.of(context);
    const titles = ['WorkPulse', 'My Tasks', 'Team', 'Profile'];
    final tabs = <Widget>[
      const _HomeTab(),
      const _TasksTab(),
      const TeamTab(),
      const ProfileTab(),
    ];
    return Scaffold(
      appBar: AppBar(
        title: Row(
          children: [
            if (_index == 0) ...[const LogoMark(size: 30), const SizedBox(width: 10)],
            Text(titles[_index]),
          ],
        ),
      ),
      body: Column(
        children: [
          if (state.streamError != null)
            Container(
              width: double.infinity,
              color: const Color(0xFF3A1620),
              padding: const EdgeInsets.all(10),
              child: Text(state.streamError!,
                  style: const TextStyle(color: C.red, fontSize: 12)),
            ),
          Expanded(child: tabs[_index]),
        ],
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _index,
        onDestinationSelected: (i) => setState(() => _index = i),
        destinations: const [
          NavigationDestination(
              icon: Icon(Icons.home_outlined),
              selectedIcon: Icon(Icons.home, color: C.cyan),
              label: 'Home'),
          NavigationDestination(
              icon: Icon(Icons.checklist_outlined),
              selectedIcon: Icon(Icons.checklist, color: C.cyan),
              label: 'Tasks'),
          NavigationDestination(
              icon: Icon(Icons.groups_outlined),
              selectedIcon: Icon(Icons.groups, color: C.cyan),
              label: 'Team'),
          NavigationDestination(
              icon: Icon(Icons.person_outline),
              selectedIcon: Icon(Icons.person, color: C.cyan),
              label: 'Profile'),
        ],
      ),
    );
  }
}

class _HomeTab extends StatelessWidget {
  const _HomeTab();

  @override
  Widget build(BuildContext context) {
    final state = AppScope.of(context);
    final me = state.me!;
    final a = state.analytics;
    final load = a.loadOf(me.id);
    final tasks = state.tasksOf(me.id);
    final open = tasks.where((t) => !t.done).toList();
    final percent = load?.percent ?? 0;
    final level = load?.level;
    final color = level == null ? C.cyan : levelColor(level);

    final now = DateTime.now();
    final today = open.where((t) =>
        t.due.year == now.year && t.due.month == now.month && t.due.day == now.day);

    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 0, 16, 24),
      children: [
        Text('${greeting()}, ${me.firstName}',
            style: const TextStyle(color: C.muted, fontSize: 15)),
        const SectionLabel("Today's workload"),
        Row(
          children: [
            Expanded(
                child: StatTile(
                    label: 'WORKLOAD',
                    value: '${percent.round()}%',
                    color: color)),
            const SizedBox(width: 12),
            Expanded(
                child: StatTile(
                    label: 'DUE SOON',
                    value: '${load?.dueSoon ?? 0}',
                    color: C.amber)),
          ],
        ),
        const SizedBox(height: 12),
        Row(
          children: [
            Expanded(
                child: StatTile(
                    label: 'OPEN TASKS',
                    value: '${open.length}',
                    color: C.cyan)),
            const SizedBox(width: 12),
            Expanded(
                child: StatTile(
                    label: 'COMPLETED',
                    value: '${load?.completed ?? 0}',
                    color: C.green)),
          ],
        ),
        if (level != null) ...[
          const SizedBox(height: 12),
          Panel(
            color: C.panel,
            child: Row(
              children: [
                Icon(
                    level == LoadLevel.high
                        ? Icons.warning_amber_rounded
                        : Icons.insights,
                    color: color),
                const SizedBox(width: 12),
                Expanded(
                  child: Text(_advice(level, load!.overdue),
                      style: const TextStyle(color: C.text, height: 1.3)),
                ),
              ],
            ),
          ),
        ],
        SectionLabel('In progress',
            trailing: Text('${today.length} due today',
                style: const TextStyle(color: C.muted, fontSize: 12))),
        if (open.isEmpty)
          const EmptyNote('No open tasks. Enjoy the calm! 🎉')
        else
          for (final t in open.take(4))
            TaskTile(task: t, onTap: () => showProgressSheet(context, t)),
        if (open.isNotEmpty) ...[
          const SectionLabel('Upcoming'),
          Panel(
            child: Row(
              children: [
                const Icon(Icons.event_note, color: C.purple),
                const SizedBox(width: 12),
                Expanded(
                  child: Text(open.first.title,
                      style: const TextStyle(
                          color: C.text, fontWeight: FontWeight.w700)),
                ),
                Text(dueText(open.first.due),
                    style: const TextStyle(color: C.muted, fontSize: 12)),
              ],
            ),
          ),
        ],
        const SizedBox(height: 16),
        const Panel(
          color: C.panel,
          child: Text(
              'Designed for fast daily updates: tap a task, drag the slider, save. That keeps the whole team\'s data current without reporting overhead.',
              style: TextStyle(color: C.muted, fontSize: 13, height: 1.35)),
        ),
      ],
    );
  }

  String _advice(LoadLevel level, int overdue) {
    if (level == LoadLevel.high) {
      return 'Your workload is high. Talk to your manager about reallocating tasks.';
    }
    if (overdue > 0) {
      return 'You have $overdue overdue task${overdue == 1 ? '' : 's'}. Update progress to keep the team informed.';
    }
    if (level == LoadLevel.mid) {
      return 'Normal capacity. Keep an eye on upcoming deadlines.';
    }
    return 'You have spare capacity and can absorb more work.';
  }
}

class _TasksTab extends StatefulWidget {
  const _TasksTab();

  @override
  State<_TasksTab> createState() => _TasksTabState();
}

class _TasksTabState extends State<_TasksTab> {
  bool _showDone = false;

  @override
  Widget build(BuildContext context) {
    final state = AppScope.of(context);
    final all = state.tasksOf(state.me!.id);
    final list = all.where((t) => t.done == _showDone).toList();
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 0, 16, 8),
          child: SegmentedButton<bool>(
            segments: [
              ButtonSegment(
                  value: false,
                  label: Text('Active (${all.where((t) => !t.done).length})')),
              ButtonSegment(
                  value: true,
                  label: Text('Completed (${all.where((t) => t.done).length})')),
            ],
            selected: {_showDone},
            onSelectionChanged: (s) => setState(() => _showDone = s.first),
          ),
        ),
        Expanded(
          child: list.isEmpty
              ? EmptyNote(_showDone
                  ? 'Nothing completed yet.'
                  : 'No active tasks assigned to you.')
              : ListView(
                  padding: const EdgeInsets.fromLTRB(16, 4, 16, 24),
                  children: [
                    for (final t in list)
                      TaskTile(
                          task: t, onTap: () => showProgressSheet(context, t)),
                  ],
                ),
        ),
      ],
    );
  }
}
